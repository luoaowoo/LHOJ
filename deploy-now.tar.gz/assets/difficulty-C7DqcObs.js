function r(e){const t=e.toLowerCase();return/入门|easy|1|2/.test(t)?"#42d392":/普及|medium|3|4/.test(t)?"#ffc247":/提高|hard|5|6/.test(t)?"#63d4eb":"#c77dff"}export{r as d};
