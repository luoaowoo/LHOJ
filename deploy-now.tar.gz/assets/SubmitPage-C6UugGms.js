import{j as e,P as K,D as ce,r as q,a1 as ue,a2 as de,U as me,f as fe,a3 as pe,a4 as k,B as x,T as w,e as h,I as j,O as be,o as H,w as N}from"./mui-BaBBaUg6.js";import{h as ve,j as xe,i as he,r as a}from"./router-zkEFJgJX.js";import{C as je}from"./CodeEditor-Bj8rHy8j.js";import{C as ge}from"./ConfirmDialog-VRUq2eAL.js";import{P as ye}from"./PageHeader-DdWuc5UK.js";import{j as Ce,F as Se,E as Re,b as Ie,s as Ee,k as Pe,m as ke}from"./index-BpumSKpO.js";import{a6 as A,a7 as z,O as J,a8 as we,a9 as ze,a0 as Be}from"./icons-5qtDcuCW.js";const Le=[{value:"bash",label:"Bash"},{value:"c",label:"C"},{value:"cc",label:"C++"},{value:"cc.cc98",label:"C++98"},{value:"cc.cc98o2",label:"C++98 (O2)"},{value:"cc.cc11",label:"C++11"},{value:"cc.cc11o2",label:"C++11 (O2)"},{value:"cc.cc14",label:"C++14"},{value:"cc.cc14o2",label:"C++14 (O2)"},{value:"cc.cc17",label:"C++17"},{value:"cc.cc17o2",label:"C++17 (O2)"},{value:"cc.cc20",label:"C++20"},{value:"cc.cc20o2",label:"C++20 (O2)"},{value:"pas",label:"Pascal"},{value:"java",label:"Java"},{value:"kt",label:"Kotlin"},{value:"kt.jvm",label:"Kotlin/JVM"},{value:"py",label:"Python"},{value:"py.py2",label:"Python 2"},{value:"py.py3",label:"Python 3"},{value:"py.pypy3",label:"PyPy 3"},{value:"php",label:"PHP"},{value:"rs",label:"Rust"},{value:"go",label:"Go"},{value:"hs",label:"Haskell"},{value:"js",label:"NodeJS"},{value:"rb",label:"Ruby"},{value:"cs",label:"C#"},{value:"r",label:"R"}],G="lh-oj.submit-language",$e=2*1024*1024,Fe=128*1024*1024;function V(s){return s.startsWith("cc")||s==="c"?s==="c"?`#include <stdio.h>

int main(void) {
  return 0;
}
`:`#include <bits/stdc++.h>
using namespace std;

int main() {
  return 0;
}
`:s.startsWith("py")?`import sys


def main():
    pass


if __name__ == "__main__":
    main()
`:s==="java"?`import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
    }
}
`:s==="go"?`package main

import "fmt"

func main() {
    fmt.Println()
}
`:s==="rs"?`fn main() {
}
`:s==="js"?`"use strict";

function main() {
}

main();
`:s==="bash"?`#!/usr/bin/env bash
set -euo pipefail
`:""}function Oe(s){return s==="java"?"java":s.startsWith("py")?"py":s==="js"?"js":s==="go"?"go":s==="rs"?"rs":s==="bash"?"sh":s==="c"?"c":"cpp"}function Te(s){return s.startsWith("cc")?"cpp":s.startsWith("py")?"python":{c:"c",pas:"pascal",java:"java",kt:"kotlin",php:"php",rs:"rust",go:"go",js:"javascript",rb:"ruby",cs:"csharp",r:"r",bash:"shell"}[s.split(".")[0]]??"plaintext"}function He(){const{id:s=""}=ve(),g=xe(),[Q]=he(),o=Q.get("tid")??"",[b,X]=a.useState(null),[Y,y]=a.useState(!0),[B,C]=a.useState(""),[L,Z]=a.useState([]),[i,$]=a.useState(()=>{try{const t=localStorage.getItem(G);return Le.some(n=>n.value===t)?t??"cc.cc17":"cc.cc17"}catch{return"cc.cc17"}}),[r,v]=a.useState(""),[c,ee]=a.useState("editor"),[u,F]=a.useState(null),[S,te]=a.useState(""),[R,O]=a.useState(!1),[T,p]=a.useState(""),[U,d]=a.useState(""),[se,I]=a.useState(!1),W=a.useRef(null),_=a.useRef(null),E=a.useRef(!1),f=`lh-oj.draft.${s}.${i}`,D=a.useRef(""),P=a.useCallback(async()=>{y(!0),C("");try{const t=await Ce(s,o||void 0);if(X(t.problem),Z(t.languages),!t.languages.length)throw new Error("当前题目没有可用的提交语言。");$(n=>{var l;return t.languages.some(m=>m.value===n)?n:((l=t.languages.find(m=>m.value==="cc.cc17"))==null?void 0:l.value)??t.languages[0].value})}catch(t){C(t instanceof Error?t.message:"加载题目失败。")}finally{y(!1)}},[s,o]);a.useEffect(()=>{if(!s){y(!1),C("缺少题目编号。");return}P()},[s,P]),a.useEffect(()=>{let t="";try{t=localStorage.getItem(f)??""}catch{t=""}v(t||V(i)),D.current=f},[f]),a.useEffect(()=>{if(D.current===f)try{r?localStorage.setItem(f,r):localStorage.removeItem(f)}catch{}},[r,f]),a.useEffect(()=>{try{localStorage.setItem(G,i)}catch{}},[i]);const ae=t=>{if(t.preventDefault(),(c==="file"?!u:!r.trim())||E.current)return;if(c==="pretest"&&!S.trim()){p("请输入自测数据。");return}if(!L.some(l=>l.value===i)){p("当前题目不允许使用所选语言提交。");return}E.current=!0,O(!0),p(""),(c==="file"&&u?Ee(s,i,u,o||void 0):c==="pretest"?Pe(s,i,r,S,o||void 0):ke(s,i,r,o||void 0)).then(l=>{if(l.rid){g(`/records/${encodeURIComponent(l.rid)}`);return}const m=`/problem/${encodeURIComponent(s)}${o?`?tid=${encodeURIComponent(o)}`:""}`;g(m,{state:{submitted:!0}})}).catch(l=>{p(l instanceof Error?l.message:"提交失败，请稍后重试。")}).finally(()=>{E.current=!1,O(!1)})};if(Y)return e.jsx(Se,{});if(B)return e.jsx(Re,{message:B,onRetry:()=>void P()});if(!b)return e.jsx(Ie,{message:"题目不存在"});const M=()=>{v(V(i)),I(!1),d("已载入代码模板。")},ne=()=>{r.trim()?I(!0):M()},le=async()=>{try{await navigator.clipboard.writeText(r),d("代码已复制。")}catch{d("复制失败，请使用编辑器菜单复制。")}},re=()=>{const t=URL.createObjectURL(new Blob([r],{type:"text/plain;charset=utf-8"})),n=document.createElement("a");n.href=t,n.download=`${b.pid??s}.${Oe(i)}`,n.click(),URL.revokeObjectURL(t),d("代码文件已下载。")},ie=t=>{var m;const n=(m=t.target.files)==null?void 0:m[0];if(t.target.value="",!n)return;if(n.size>$e){d("代码文件不能超过 2 MiB。");return}const l=new FileReader;l.onload=()=>{v(typeof l.result=="string"?l.result:""),d(`已载入 ${n.name}。`)},l.onerror=()=>d("文件读取失败。"),l.readAsText(n)},oe=t=>{var l;const n=((l=t.target.files)==null?void 0:l[0])??null;if(t.target.value="",n&&n.size>Fe){F(null),p("提交文件不能超过 128 MiB。");return}F(n),p("")};return e.jsxs(K,{component:"form",variant:"outlined",onSubmit:ae,"data-submit-form":"true",sx:{p:{xs:2,sm:3}},children:[e.jsx(ye,{title:b.title,subtitle:`#${b.pid??b.docId}${o?` · 比赛提交 #${o}`:""}`}),e.jsx(ce,{sx:{mb:2.5}}),e.jsxs(q,{spacing:2.5,children:[e.jsxs(ue,{fullWidth:!0,children:[e.jsx(de,{id:"language-label",children:"语言"}),e.jsx(me,{labelId:"language-label",label:"语言",value:i,onChange:t=>$(t.target.value),children:L.map(t=>e.jsx(fe,{value:t.value,children:t.label},t.value))})]}),e.jsxs(pe,{exclusive:!0,size:"small",value:c,onChange:(t,n)=>{n&&ee(n)},"aria-label":"提交方式",sx:{alignSelf:"flex-start","& .MuiToggleButton-root":{gap:.75}},children:[e.jsxs(k,{value:"editor",children:[e.jsx(A,{size:16})," 编辑器"]}),e.jsxs(k,{value:"file",children:[e.jsx(z,{size:16})," 文件"]}),e.jsxs(k,{value:"pretest",children:[e.jsx(J,{size:16})," 自测"]})]}),c!=="file"?e.jsxs(x,{children:[e.jsxs(x,{sx:{display:"flex",alignItems:"center",gap:.5,mb:.8,flexWrap:"wrap"},children:[e.jsxs(w,{variant:"subtitle2",sx:{mr:.5,display:"flex",alignItems:"center",gap:.7},children:[e.jsx(A,{size:17})," 在线代码编辑器"]}),e.jsx(x,{sx:{flex:1}}),e.jsx(h,{title:"载入模板",children:e.jsx(j,{size:"small",onClick:ne,"aria-label":"载入代码模板",children:e.jsx(we,{size:17})})}),e.jsx(h,{title:"复制代码",children:e.jsx(j,{size:"small",onClick:()=>void le(),"aria-label":"复制代码",children:e.jsx(ze,{size:17})})}),e.jsx(h,{title:"导入文件",children:e.jsx(j,{size:"small",onClick:()=>{var t;return(t=W.current)==null?void 0:t.click()},"aria-label":"导入代码文件",children:e.jsx(z,{size:17})})}),e.jsx(h,{title:"下载代码",children:e.jsx(j,{size:"small",onClick:re,"aria-label":"下载代码文件",children:e.jsx(Be,{size:17})})}),e.jsx("input",{ref:W,hidden:!0,type:"file",accept:".c,.cc,.cpp,.h,.hpp,.py,.java,.js,.ts,.go,.rs,.txt",onChange:ie})]}),e.jsx(je,{value:r,onChange:v,language:Te(i),onSubmitShortcut:()=>{var t;r.trim()&&!R&&((t=document.querySelector("form[data-submit-form]"))==null||t.requestSubmit())}}),e.jsxs(w,{variant:"caption",color:"text.secondary",sx:{display:"block",mt:.7},children:[r.split(`
`).length," 行 · 草稿自动保存在当前浏览器 · Ctrl/⌘ + Enter 提交"]}),c==="pretest"?e.jsx(be,{fullWidth:!0,multiline:!0,minRows:4,maxRows:12,label:"自测输入",value:S,onChange:t=>te(t.target.value),sx:{mt:2},inputProps:{spellCheck:!1}}):null]}):e.jsx(K,{variant:"outlined",sx:{p:2},children:e.jsxs(q,{direction:{xs:"column",sm:"row"},spacing:1.5,alignItems:{sm:"center"},children:[e.jsx(H,{variant:"outlined",startIcon:e.jsx(z,{size:16}),onClick:()=>{var t;return(t=_.current)==null?void 0:t.click()},children:"选择文件"}),e.jsx(w,{variant:"body2",color:u?"text.primary":"text.secondary",sx:{overflowWrap:"anywhere"},children:u?`${u.name} · ${(u.size/1024).toFixed(1)} KiB`:"尚未选择文件"}),e.jsx("input",{ref:_,hidden:!0,type:"file",onChange:oe})]})}),T&&e.jsx(N,{severity:"error",children:T}),U&&e.jsx(N,{severity:"info",onClose:()=>d(""),children:U}),e.jsx(x,{sx:{display:"flex",justifyContent:"flex-end"},children:e.jsx(H,{type:"submit",variant:"contained",startIcon:e.jsx(J,{size:16}),disabled:(c==="file"?!u:!r.trim())||R,children:R?"提交中":c==="pretest"?"运行自测":"提交"})})]}),e.jsx(ge,{open:se,title:"载入代码模板？",content:"当前编辑器内容将被所选语言的默认模板替换。",confirmLabel:"替换",cancelLabel:"取消",destructive:!1,onConfirm:M,onClose:()=>I(!1)})]})}export{He as default};
